echo  "\n 4.amazon-linux-extrasで使用中のパッケージと使えるパッケージを確認\n "
amazon-linux-extras
echo  "\n 5.lamp-mariadb10.2-php7.2を使用停止しました\n "
sudo amazon-linux-extras disable lamp-mariadb10.2-php7.2

echo  "\n 6.PHP8.0を有効化しました\n "
sudo amazon-linux-extras enable php8.0