rm step1_setup1.sh & rm step1_setup2.sh & rm step1_setup3.sh
rm step2_db1.sh & rm step2_db2.sh
rm README_.md
rm LaravelSetting.zip
rm short_setup.sh
rm step3_cleanUp1.sh
