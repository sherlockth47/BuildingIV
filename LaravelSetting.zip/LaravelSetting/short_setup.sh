echo "\n 1.パッケージのアップデートしました\n"
sudo yum update -y

echo "\n 2.PHPのパッケージをすべてアンインストールしました\n "
sudo yum -y remove php-*

echo "\n 3.amazon-linux-extrasをアップデートしました\n "
sudo yum update -y amazon-linux-extras

echo  "\n 4.amazon-linux-extrasで使用中のパッケージと使えるパッケージを確認\n "
amazon-linux-extras

echo  "\n 5.lamp-mariadb10.2-php7.2を使用停止しました\n "
sudo amazon-linux-extras disable lamp-mariadb10.2-php7.2

echo  "\n 6.PHP8.0を有効化しました\n "
sudo amazon-linux-extras enable php8.0

echo  "\n 7-1.インストールするパッケージの案内があったので、表示されたコマンドを実行しました\n "
sudo yum clean metadata && sudo yum install php-cli php-pdo php-fpm php-mysqlnd

echo  "\n 7-2.インストールするパッケージの案内があったので、表示されたコマンドを実行しました\n "
sudo yum install php-cli php-common php-devel php-fpm php-gd php-mysqlnd php-mbstring php-pdo php-xml

echo  "\n 8-1.apacheなどを再起動しました\n "
sudo systemctl restart httpd.service

echo  "\n 8-2.apacheなどを再起動しました\n "
sudo systemctl restart php-fpm.service

echo  "\n 9.xdebugの設定を再度インストールしました\n "
sudo yum install php-pear php-devel
sudo pecl uninstall xdebug
sudo pecl install xdebug

echo  "\n 1.MariaDBデフォルト確認しました\n "
sudo yum list installed | grep mariadb

echo  "\n 2.MariaDBのインストールしました\n "
sudo amazon-linux-extras install mariadb10.5 -y

echo  "\n 3.Apache, MariaDBの起動しました\n "
sudo systemctl start mariadb

sudo mysql_secure_installation

echo  "\n 4-2.MaridaDBの自動起動を有効化しました\n "
sudo systemctl is-enabled mariadb

echo  "\n 5-1. Composerインストール（バージョン指定）しました\n "
curl -sS https://getcomposer.org/installer | php -- --version=2.3.5

echo  "\n 5-2. Composerインストールしました\n "
sudo mv composer.phar /usr/bin/composer

echo  "\n 5-3. Composerインストールしました\n "
composer

rm step1_setup1.sh & rm step1_setup2.sh & rm step1_setup3.sh
rm step2_db1.sh & rm step2_db2.sh
rm README_.md
rm LaravelSetting.zip
rm short_setup.sh
rm step3_cleanUp1.sh