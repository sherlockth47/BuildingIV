echo "\n 1.パッケージのアップデートしました\n"
sudo yum update -y

echo "\n 2.PHPのパッケージをすべてアンインストールしました\n "
sudo yum -y remove php-*

echo "\n 3.amazon-linux-extrasをアップデートしました\n "
sudo yum update -y amazon-linux-extras