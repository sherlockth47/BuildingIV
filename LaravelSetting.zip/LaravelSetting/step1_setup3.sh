echo  "\n 7-1.インストールするパッケージの案内があったので、表示されたコマンドを実行しました\n "
sudo yum clean metadata && sudo yum install php-cli php-pdo php-fpm php-mysqlnd

echo  "\n 7-2.インストールするパッケージの案内があったので、表示されたコマンドを実行しました\n "
sudo yum install php-cli php-common php-devel php-fpm php-gd php-mysqlnd php-mbstring php-pdo php-xml

echo  "\n 8-1.apacheなどを再起動しました\n "
sudo systemctl restart httpd.service

echo  "\n 8-2.apacheなどを再起動しました\n "
sudo systemctl restart php-fpm.service

echo  "\n 9.xdebugの設定を再度インストールしました\n "
sudo yum install php-pear php-devel
sudo pecl uninstall xdebug
sudo pecl install xdebug