echo  "\n 1.MariaDBデフォルト確認しました\n "
sudo yum list installed | grep mariadb

echo  "\n 2.MariaDBのインストールしました\n "
sudo amazon-linux-extras install mariadb10.5 -y

echo  "\n 3.Apache, MariaDBの起動しました\n "
sudo systemctl start mariadb

sudo mysql_secure_installation

echo  "\n 4-2.MaridaDBの自動起動を有効化しました\n "
sudo systemctl is-enabled mariadb