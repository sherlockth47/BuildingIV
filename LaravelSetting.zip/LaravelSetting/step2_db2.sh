echo  "\n 5-1. Composerインストール（バージョン指定）しました\n "
curl -sS https://getcomposer.org/installer | php -- --version=2.3.5

echo  "\n 5-2. Composerインストールしました\n "
sudo mv composer.phar /usr/bin/composer

echo  "\n 5-3. Composerインストールしました\n "
composer