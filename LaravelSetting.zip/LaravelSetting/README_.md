AWSCloud9にアップロードして使います。
シェルを実行するコマンドは以下になります。

$ sh 実行したいシェルファイル（拡張子が.sh）

step1_setup1.shから順番に実行していきます。

step1_setup3.shでは3回terminalで質問されます。
```
Is this ok [y/d/N]:
```
と聞かれるので3回とも 'y'(yesに相当)を選択して下さい


## step2_db1
データベースのパスワードの変更確認が来ますので変更していきます。

```
初回設定の入力項目
Enter current password for root (enter for none):  [Enterキー]
Switch to unix_socket authentication [Y/n] y
Set root password? [Y/n] y

# ここで設定しているパスワード
New password: root
Re-enter new password: root

Remove anonymous users? [Y/n] y 
Disallow root login remotely? [Y/n] y
Remove test database and access to it? [Y/n] y
Reload privilege tables now? [Y/n] y
```
